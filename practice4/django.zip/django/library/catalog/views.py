from django.shortcuts import render

# Create your views here.

def book_detail(request):
    books = [
        {
            'title': 'Big Black Book',
            'author': 'Big Black Author',
            'year': 'Big Black Year',
        },
        {
            'title': 'Small Black Book',
            'author': 'Small Black Author',
            'year': 'Small Black Year',
        }
    ]
    return render(request, 'catalog/book_detail.html', {'books': books})
